export interface CompanyInput {
  company_name: string;
  city: string;
  state?: string;
  category?: string;
}

const detectDelimiter = (line: string): string => {
  const commaCount = (line.match(/,/g) || []).length;
  const semicolonCount = (line.match(/;/g) || []).length;
  const tabCount = (line.match(/\t/g) || []).length;

  if (tabCount > commaCount && tabCount > semicolonCount) return '\t';
  if (semicolonCount > commaCount) return ';';
  return ',';
};

const splitCSVLine = (line: string, delimiter: string = ','): string[] => {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];

    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === delimiter && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }

  result.push(current.trim());
  return result;
};

const hasHeader = (firstLine: string[]): boolean => {
  const normalized = firstLine.map(cell => cell.toLowerCase().trim());

  const hasNameHeader = normalized.some(cell =>
    cell.includes('empresa') ||
    cell.includes('nome') ||
    cell === 'name' ||
    cell === 'company' ||
    cell.includes('restaurante')
  );

  const hasCityHeader = normalized.some(cell =>
    cell.includes('cidade') ||
    cell === 'city' ||
    cell.includes('local')
  );

  return hasNameHeader || hasCityHeader;
};

export const parseCSV = (text: string): CompanyInput[] => {
  const allLines = text.split(/\r?\n/);
  console.log('Total de linhas brutas no arquivo:', allLines.length);

  const lines = allLines
    .map(line => line.trim())
    .filter(line => line.length > 0);

  console.log('Linhas não vazias:', lines.length);

  if (lines.length === 0) {
    throw new Error('Arquivo vazio. Por favor, adicione dados à planilha.');
  }

  const delimiter = detectDelimiter(lines[0]);
  console.log('Delimitador detectado:', delimiter === ',' ? 'vírgula' : delimiter === ';' ? 'ponto-e-vírgula' : 'tab');

  const firstLineValues = splitCSVLine(lines[0], delimiter);
  const hasHeaderRow = hasHeader(firstLineValues);

  console.log('Primeira linha:', firstLineValues);
  console.log('Tem cabeçalho?', hasHeaderRow);

  let nameIndex = 0;
  let cityIndex = 1;
  let stateIndex = 2;
  let categoryIndex = -1;

  let startIndex = 0;

  if (hasHeaderRow) {
    startIndex = 1;
    const headers = firstLineValues.map(h =>
      h.trim().toLowerCase().replace(/^"|"$/g, '')
    );

    console.log('Cabeçalhos detectados:', headers);

    const foundNameIndex = headers.findIndex(h =>
      h.includes('empresa') || h.includes('nome') || h === 'name' || h === 'company' || h.includes('restaurante')
    );
    const foundCityIndex = headers.findIndex(h =>
      h.includes('cidade') || h === 'city' || h.includes('local')
    );
    const foundStateIndex = headers.findIndex(h =>
      h.includes('estado') || h === 'state' || h === 'uf'
    );
    const foundCategoryIndex = headers.findIndex(h =>
      h.includes('categoria') || h === 'category' || h.includes('tipo')
    );

    if (foundNameIndex !== -1) nameIndex = foundNameIndex;
    if (foundCityIndex !== -1) cityIndex = foundCityIndex;
    if (foundStateIndex !== -1) stateIndex = foundStateIndex;
    if (foundCategoryIndex !== -1) categoryIndex = foundCategoryIndex;
  }

  console.log(`Índices das colunas - Nome: ${nameIndex}, Cidade: ${cityIndex}, Estado: ${stateIndex}`);

  const companies: CompanyInput[] = [];
  let skippedLines = 0;

  for (let i = startIndex; i < lines.length; i++) {
    try {
      const values = splitCSVLine(lines[i], delimiter);

      if (values.length < 2) {
        if (i < startIndex + 3) {
          console.log(`Linha ${i + 1} tem menos de 2 colunas:`, values);
        }
        skippedLines++;
        continue;
      }

      const company_name = (values[nameIndex] || '').replace(/^"|"$/g, '').trim();
      const city = (values[cityIndex] || '').replace(/^"|"$/g, '').trim();

      if (!company_name || !city) {
        if (i < startIndex + 3) {
          console.log(`Linha ${i + 1} está vazia (nome ou cidade faltando):`, { company_name, city, values });
        }
        skippedLines++;
        continue;
      }

      companies.push({
        company_name,
        city,
        state: stateIndex !== -1 && values[stateIndex]
          ? values[stateIndex].replace(/^"|"$/g, '').trim()
          : undefined,
        category: categoryIndex !== -1 && values[categoryIndex]
          ? values[categoryIndex].replace(/^"|"$/g, '').trim()
          : undefined,
      });
    } catch (error) {
      console.warn(`Erro ao processar linha ${i + 1}, pulando...`, error);
      skippedLines++;
      continue;
    }
  }

  console.log(`Empresas válidas encontradas: ${companies.length}`);
  console.log(`Linhas puladas: ${skippedLines}`);

  if (companies.length === 0) {
    throw new Error('Nenhuma empresa válida encontrada. Verifique o formato do arquivo.');
  }

  return companies;
};

const generatePrioritizedImprovements = (rating: number, totalReviews: number, hasWebsite: boolean, hasPhotos: boolean) => {
  const improvements: Array<{ priority: number; text: string }> = [];

  if (totalReviews < 10) {
    improvements.push({ priority: 10, text: 'URGENTE: Solicitar avaliações de clientes (menos de 10 avaliações impacta muito no ranking)' });
  } else if (totalReviews < 20) {
    improvements.push({ priority: 8, text: 'Aumentar número de avaliações para pelo menos 20' });
  } else if (totalReviews < 50) {
    improvements.push({ priority: 5, text: 'Continuar solicitando avaliações de clientes satisfeitos' });
  }

  if (rating < 3.5) {
    improvements.push({ priority: 10, text: 'CRÍTICO: Melhorar qualidade do atendimento (nota muito baixa)' });
    improvements.push({ priority: 9, text: 'Responder TODAS as avaliações negativas com soluções concretas' });
  } else if (rating < 4.0) {
    improvements.push({ priority: 7, text: 'Melhorar qualidade do atendimento para atingir nota 4.0+' });
    improvements.push({ priority: 6, text: 'Responder avaliações negativas demonstrando atenção ao cliente' });
  } else if (rating < 4.5) {
    improvements.push({ priority: 4, text: 'Otimizar atendimento para alcançar nota superior a 4.5' });
  }

  if (!hasWebsite) {
    improvements.push({ priority: 6, text: 'Adicionar website ao perfil GMN (aumenta credibilidade)' });
  }

  if (!hasPhotos) {
    improvements.push({ priority: 8, text: 'Adicionar fotos de alta qualidade (fachada, interior, produtos/serviços)' });
  } else {
    improvements.push({ priority: 3, text: 'Atualizar fotos regularmente (recomendado mensalmente)' });
  }

  if (totalReviews > 5 && rating >= 4.0) {
    improvements.push({ priority: 5, text: 'Responder todas as avaliações (aumenta engajamento em até 30%)' });
  }

  improvements.push({ priority: 4, text: 'Postar atualizações semanais (ofertas, novidades, eventos)' });
  improvements.push({ priority: 3, text: 'Verificar e atualizar horário de funcionamento regularmente' });
  improvements.push({ priority: 2, text: 'Adicionar atributos do negócio (WiFi, estacionamento, acessibilidade, etc)' });
  improvements.push({ priority: 2, text: 'Incluir produtos/serviços com preços no perfil' });

  if (rating >= 4.5 && totalReviews >= 50) {
    improvements.push({ priority: 1, text: 'Manter excelência: perfil está bem otimizado, continue engajando' });
  }

  return improvements
    .sort((a, b) => b.priority - a.priority)
    .map(item => item.text);
};

export const generateMockAnalysis = (company: CompanyInput) => {
  const hasProfile = Math.random() > 0.3;

  if (!hasProfile) {
    return {
      ...company,
      has_gmn_profile: false,
      gmn_name: null,
      address: null,
      phone: null,
      website: null,
      business_hours: null,
      rating: null,
      total_reviews: 0,
      review_keywords: null,
      improvement_points: [
        'URGENTE: Criar perfil no Google Meu Negócio (essencial para ser encontrado)',
        'Adicionar informações completas (endereço, telefone, horário, fotos)',
        'Solicitar avaliações dos primeiros clientes',
        'Publicar fotos de alta qualidade do estabelecimento',
        'Adicionar produtos/serviços oferecidos'
      ],
    };
  }

  const rating = Number((3.5 + Math.random() * 1.5).toFixed(2));
  const totalReviews = Math.floor(Math.random() * 150) + 5;
  const hasWebsite = Math.random() > 0.4;
  const hasPhotos = Math.random() > 0.3;

  const allKeywords = [
    'atendimento', 'qualidade', 'preço', 'localização', 'rapidez',
    'profissionalismo', 'recomendo', 'excelente', 'ótimo', 'bom',
    'variedade', 'produtos', 'serviços', 'ambiente', 'equipe'
  ];

  const keywords = allKeywords
    .sort(() => Math.random() - 0.5)
    .slice(0, Math.floor(Math.random() * 4) + 3);

  const improvements = generatePrioritizedImprovements(rating, totalReviews, hasWebsite, hasPhotos);

  return {
    ...company,
    has_gmn_profile: true,
    gmn_name: company.company_name,
    address: `Rua Exemplo, 123 - Centro, ${company.city} - ${company.state || 'SP'}`,
    phone: `(${Math.floor(Math.random() * 90) + 10}) ${Math.floor(Math.random() * 90000) + 10000}-${Math.floor(Math.random() * 9000) + 1000}`,
    website: hasWebsite ? `https://www.${company.company_name.toLowerCase().replace(/\s+/g, '')}.com.br` : null,
    business_hours: {
      monday: '08:00-18:00',
      tuesday: '08:00-18:00',
      wednesday: '08:00-18:00',
      thursday: '08:00-18:00',
      friday: '08:00-18:00',
      saturday: '08:00-12:00',
    },
    rating,
    total_reviews: totalReviews,
    review_keywords: keywords,
    improvement_points: improvements,
  };
};
