import { useState } from 'react';
import { FileUpload } from './components/FileUpload';
import { ResultsTable } from './components/ResultsTable';
import { AuditForm } from './components/AuditForm';
import { ComprehensiveAuditReport } from './components/ComprehensiveAuditReport';
import { parseCSV, generateMockAnalysis } from './utils/spreadsheetParser';
import { supabase } from './lib/supabase';
import { Database } from './lib/supabase';
import { generateComprehensiveAudit, ComprehensiveAuditResult } from './services/enhanced-openai';
import { BarChart3, FileSpreadsheet, Sparkles } from 'lucide-react';

type Company = Database['public']['Tables']['companies']['Row'];

type AppMode = 'selection' | 'csv-analysis' | 'ai-audit';

function App() {
  const [mode, setMode] = useState<AppMode>('selection');
  const [isProcessing, setIsProcessing] = useState(false);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [sessionName, setSessionName] = useState('');
  const [showResults, setShowResults] = useState(false);
  const [comprehensiveAudit, setComprehensiveAudit] = useState<ComprehensiveAuditResult | null>(null);
  const [auditSegment, setAuditSegment] = useState('');
  const [auditCity, setAuditCity] = useState('');

  const processFile = async (file: File) => {
    setIsProcessing(true);
    try {
      const text = await file.text();
      console.log('Tamanho do arquivo:', text.length, 'caracteres');

      const parsedCompanies = parseCSV(text);
      console.log('Empresas parseadas:', parsedCompanies.length);

      if (parsedCompanies.length === 0) {
        alert('Nenhuma empresa válida encontrada na planilha.');
        setIsProcessing(false);
        return;
      }

      const sessionNameValue = `Análise ${new Date().toLocaleDateString('pt-BR')} - ${file.name}`;

      const { data: session, error: sessionError } = await supabase
        .from('analysis_sessions')
        .insert({
          name: sessionNameValue,
          total_companies: parsedCompanies.length,
        })
        .select()
        .single();

      if (sessionError || !session) {
        console.error('Erro ao criar sessão:', sessionError);
        throw new Error('Erro ao criar sessão de análise');
      }

      console.log('Sessão criada:', session.id);

      const analyzedCompanies = parsedCompanies.map(company =>
        generateMockAnalysis(company)
      );

      const companiesWithSession = analyzedCompanies.map(company => ({
        ...company,
        session_id: session.id,
      }));

      console.log('Preparando para inserir', companiesWithSession.length, 'empresas');

      const BATCH_SIZE = 100;
      const allInsertedCompanies: Company[] = [];

      for (let i = 0; i < companiesWithSession.length; i += BATCH_SIZE) {
        const batch = companiesWithSession.slice(i, i + BATCH_SIZE);
        console.log(`Inserindo lote ${Math.floor(i / BATCH_SIZE) + 1}: ${batch.length} empresas`);

        const { data: insertedBatch, error: batchError } = await supabase
          .from('companies')
          .insert(batch)
          .select();

        if (batchError) {
          console.error('Erro ao inserir lote:', batchError);
          throw new Error(`Erro ao salvar empresas (lote ${Math.floor(i / BATCH_SIZE) + 1}): ${batchError.message}`);
        }

        if (insertedBatch) {
          allInsertedCompanies.push(...insertedBatch);
          console.log(`Lote inserido com sucesso. Total acumulado: ${allInsertedCompanies.length}`);
        }
      }

      console.log('Total de empresas inseridas:', allInsertedCompanies.length);

      const companiesWithGMN = allInsertedCompanies.filter(c => c.has_gmn_profile).length;

      await supabase
        .from('analysis_sessions')
        .update({ companies_with_gmn: companiesWithGMN })
        .eq('id', session.id);

      setCompanies(allInsertedCompanies);
      setSessionName(sessionNameValue);
      setShowResults(true);
    } catch (error) {
      console.error('Erro ao processar arquivo:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
      alert(`Erro ao processar o arquivo: ${errorMessage}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const resetAnalysis = () => {
    setShowResults(false);
    setCompanies([]);
    setSessionName('');
    setMode('selection');
  };

  const handleAuditSubmit = async (segment: string, city: string) => {
    setIsProcessing(true);
    setAuditSegment(segment);
    setAuditCity(city);

    try {
      const result = await generateComprehensiveAudit(segment, city);

      const { data: audit, error: auditError } = await supabase
        .from('gmn_audits')
        .insert({
          segment,
          city,
          overall_score: result.overallScore,
          compliance_status: result.overallScore >= 80 ? 'green' : result.overallScore >= 50 ? 'yellow' : 'red',
          opportunities: [],
          suggestions: [],
          local_comparison: {
            bestInSegment: result.bestInSegment.companyName,
            bestScore: result.bestInSegment.score
          },
          ai_analysis: `Análise completa de ${result.companies.length} empresas`,
          companies_analyzed: result.companies.length,
        })
        .select()
        .single();

      if (auditError || !audit) {
        console.error('Erro ao salvar auditoria:', auditError);
      }

      if (audit && result.companies.length > 0) {
        const empresasData = result.companies.map(company => ({
          audit_id: audit.id,
          company_name: company.razaoSocial,
          city: company.cidade,
          has_gmn_profile: company.statusGMN === 'possui',
          rating: null,
          total_reviews: null,
          verification_status: company.criterios.presencaVerificacao.detalhes,
          nap_consistency_score: company.criterios.consistenciaNAP.score,
          has_products: null,
          images_count: null,
          has_geotags: null,
          posts_per_week: null,
          review_response_rate: company.criterios.respostasProprietario.score,
          seo_score: company.criterios.palavrasChaveSEO.score,
          engagement_score: company.criterios.postagensRecentes.score,
          improvement_points: company.melhoriasPrioritarias,
          should_invite_for_optimization: company.scoreGeral < 70,
        }));

        await supabase.from('gmn_empresas').insert(empresasData);
      }

      setComprehensiveAudit(result);
      setMode('ai-audit');
    } catch (error) {
      console.error('Erro ao gerar auditoria:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
      alert(`Erro ao gerar auditoria: ${errorMessage}`);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen animated-gradient-bg">
      <div className="max-w-7xl mx-auto px-4 py-8 relative z-10">
        <header className="mb-8 relative z-10">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-14 h-14 bg-gradient-to-br from-blue-400 to-blue-600 rounded-xl flex items-center justify-center shadow-xl">
              <BarChart3 className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-white drop-shadow-lg">GMN SmartAudit 2.0</h1>
              <p className="text-blue-100 text-lg">Auditoria Inteligente do Google Meu Negócio</p>
            </div>
          </div>
        </header>

        {mode === 'selection' && (
          <div className="max-w-4xl mx-auto">
            <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl border border-white/20 p-8 mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                Escolha o tipo de análise
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <button
                  onClick={() => setMode('ai-audit')}
                  className="group bg-gradient-to-br from-blue-500 to-blue-700 rounded-2xl p-8 text-left transition-all duration-300 hover:shadow-2xl hover:scale-105"
                >
                  <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mb-4 group-hover:bg-white/30 transition-colors">
                    <Sparkles className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2">
                    Auditoria com IA
                  </h3>
                  <p className="text-blue-50 mb-4">
                    Análise inteligente por segmento e cidade com insights gerados por IA
                  </p>
                  <div className="flex items-center text-white font-semibold">
                    <span>Começar auditoria</span>
                    <span className="ml-2 group-hover:ml-4 transition-all">→</span>
                  </div>
                </button>

                <button
                  onClick={() => setMode('csv-analysis')}
                  className="group bg-white rounded-2xl p-8 text-left border-2 border-gray-200 transition-all duration-300 hover:shadow-2xl hover:scale-105 hover:border-blue-500"
                >
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mb-4 transition-colors">
                    <FileSpreadsheet className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">
                    Análise por Planilha
                  </h3>
                  <p className="text-gray-600 mb-4">
                    Upload de CSV com lista de empresas para análise em massa
                  </p>
                  <div className="flex items-center text-blue-600 font-semibold">
                    <span>Fazer upload</span>
                    <span className="ml-2 group-hover:ml-4 transition-all">→</span>
                  </div>
                </button>
              </div>
            </div>

            <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 text-center">
              <p className="text-gray-700 text-sm">
                <strong>Nova funcionalidade:</strong> Agora você pode fazer auditorias inteligentes com IA,
                analisando segmentos inteiros de mercado e recebendo insights personalizados.
              </p>
            </div>
          </div>
        )}

        {mode === 'ai-audit' && !comprehensiveAudit && (
          <div>
            <button
              onClick={() => setMode('selection')}
              className="mb-6 px-4 py-2 bg-white/20 hover:bg-white/30 text-white font-medium rounded-lg transition-colors backdrop-blur-sm"
            >
              ← Voltar
            </button>
            <AuditForm onSubmit={handleAuditSubmit} isProcessing={isProcessing} />
          </div>
        )}

        {mode === 'ai-audit' && comprehensiveAudit && (
          <div>
            <button
              onClick={resetAnalysis}
              className="mb-6 px-4 py-2 bg-white/20 hover:bg-white/30 text-white font-medium rounded-lg transition-colors backdrop-blur-sm"
            >
              ← Nova Auditoria
            </button>
            <ComprehensiveAuditReport
              audit={comprehensiveAudit}
              segment={auditSegment}
              city={auditCity}
            />
          </div>
        )}

        {mode === 'csv-analysis' && !showResults && (
          <div className="max-w-3xl mx-auto">
            <button
              onClick={() => setMode('selection')}
              className="mb-6 px-4 py-2 bg-white/20 hover:bg-white/30 text-white font-medium rounded-lg transition-colors backdrop-blur-sm"
            >
              ← Voltar
            </button>
            <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl border border-white/20 p-8 mb-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Como funciona?</h2>
              <div className="space-y-3 text-gray-700">
                <div className="flex gap-3">
                  <span className="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-semibold">1</span>
                  <p>Faça upload de uma planilha CSV contendo nome e cidade das empresas</p>
                </div>
                <div className="flex gap-3">
                  <span className="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-semibold">2</span>
                  <p>O sistema analisa automaticamente a presença de cada empresa no Google Meu Negócio</p>
                </div>
                <div className="flex gap-3">
                  <span className="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-semibold">3</span>
                  <p>Receba um relatório completo com dados, avaliações e pontos de melhoria</p>
                </div>
                <div className="flex gap-3">
                  <span className="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-semibold">4</span>
                  <p>Exporte os resultados em Excel ou imprima o relatório para usar em suas estratégias comerciais</p>
                </div>
              </div>
            </div>

            <FileUpload onFileSelect={processFile} isProcessing={isProcessing} />

            <div className="mt-6 bg-white/90 backdrop-blur-sm border border-white/30 rounded-xl p-4">
              <p className="text-sm text-gray-800">
                <strong>Formato da planilha:</strong> Sua planilha CSV deve conter pelo menos duas colunas:
                <span className="font-mono bg-gray-100 px-2 py-0.5 rounded ml-2">Nome da Empresa</span> e
                <span className="font-mono bg-gray-100 px-2 py-0.5 rounded ml-2">Cidade</span>.
                Colunas opcionais: Estado, Categoria.
              </p>
            </div>
          </div>
        )}

        {mode === 'csv-analysis' && showResults && (
          <div>
            <button
              onClick={resetAnalysis}
              className="mb-6 px-4 py-2 bg-white/20 hover:bg-white/30 text-white font-medium rounded-lg transition-colors backdrop-blur-sm"
            >
              ← Nova Análise
            </button>
            <ResultsTable companies={companies} sessionName={sessionName} />
          </div>
        )}
      </div>

      <footer className="mt-16 pb-8 text-center text-sm text-blue-100">
        <p>GMN SmartAudit AI - Auditoria inteligente de presença digital local</p>
      </footer>
    </div>
  );
}

export default App;
